// backend/data/products.js
module.exports = [
  { name: "T-shirt", price: 499 },
  { name: "Jeans", price: 999 },
  { name: "Sneakers", price: 1999 },
  { name: "Cap", price: 299 },
  { name: "Hoodie", price: 1299 },
  { name: "Watch", price: 1599 },
];
